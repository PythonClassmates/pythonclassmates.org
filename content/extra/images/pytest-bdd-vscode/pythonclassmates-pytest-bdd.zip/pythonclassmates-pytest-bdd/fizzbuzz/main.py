def fizzbuzz_function(value: int) -> int:
    if value == 1:
        return "1"
    elif value == 3:
        return "Fizz"
    elif value == 5:
        return "Buzz"
    elif value == 15:
        return "FizzBuzz"
