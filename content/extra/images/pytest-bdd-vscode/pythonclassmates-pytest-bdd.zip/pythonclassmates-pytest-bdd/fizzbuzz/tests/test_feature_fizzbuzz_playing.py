"""Utilisation de FizzBuzz feature tests."""

from pytest_bdd import given, scenario, then, when
from pytest_bdd.parsers import parse

from fizzbuzz.main import fizzbuzz_function


@scenario("features/fizzbuzz_playing.feature", "Lancer FizzBuzz pour obtenir Buzz")
def test_lancer_fizzbuzz_pour_obtenir_buzz():
    """Lancer FizzBuzz pour obtenir Buzz."""


@scenario("features/fizzbuzz_playing.feature", "Lancer FizzBuzz pour obtenir Fizz")
def test_lancer_fizzbuzz_pour_obtenir_fizz():
    """Lancer FizzBuzz pour obtenir Fizz."""


@scenario("features/fizzbuzz_playing.feature", "Lancer FizzBuzz pour obtenir FizzBuzz")
def test_lancer_fizzbuzz_pour_obtenir_fizzbuzz():
    """Lancer FizzBuzz pour obtenir FizzBuzz."""


@scenario(
    "features/fizzbuzz_playing.feature",
    "Lancer FizzBuzz pour obtenir le chiffre renseigné",
)
def test_lancer_fizzbuzz_pour_obtenir_le_chiffre_renseigné():
    """Lancer FizzBuzz pour obtenir le chiffre renseigné."""


@given("Je lance FizzBuzz")
def je_lance_fizzbuzz():
    """Je lance FizzBuzz."""
    pass


@when("Je renseigne le nombre 1", target_fixture="result")
def je_renseigne_le_nombre_1():
    """Je renseigne le nombre 1."""
    return fizzbuzz_function(1)


@when("Je renseigne le nombre 15", target_fixture="result")
def je_renseigne_le_nombre_15():
    """Je renseigne le nombre 15."""
    return fizzbuzz_function(15)


@when("Je renseigne le nombre 3", target_fixture="result")
def je_renseigne_le_nombre_3():
    """Je renseigne le nombre 3."""
    return fizzbuzz_function(3)


@when("Je renseigne le nombre 5", target_fixture="result")
def je_renseigne_le_nombre_5():
    """Je renseigne le nombre 5."""
    return fizzbuzz_function(5)


@then('Le résultat est "1"')
def le_résultat_est_1(result):
    """Le résultat est "1"."""
    assert result == "1"


@then('Le résultat est "Buzz"')
def le_résultat_est_buzz(result):
    """Le résultat est "Buzz"."""
    assert result == "Buzz"


@then('Le résultat est "Fizz"')
def le_résultat_est_fizz(result):
    """Le résultat est "Fizz"."""
    assert result == "Fizz"


@then('Le résultat est "FizzBuzz"')
def le_résultat_est_fizzbuzz(result):
    """Le résultat est "FizzBuzz"."""
    assert result == "FizzBuzz"
